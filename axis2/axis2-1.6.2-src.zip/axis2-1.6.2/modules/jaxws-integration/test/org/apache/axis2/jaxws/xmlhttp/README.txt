The xmlhttp test the XML HTTP protocol.

The structure of the tests will be 

org.apache.axis2.jaxws.xmlhttp.
                               provider.
                                        payload.
                                                string. ...META_INF, etc.
                                                source. ...META_INF, etc.
                                        message.
                                                string. ...META_INF, etc.
                                                source. ...META_INF, etc.
                                                datasource ...META_INF, etc.
                               webservice.
                                          sei.
                                          impl.
                                               META_INF ...
                               
                               clientTests. dispatch.
                                                     string
                                                     source
                                                     datasource
                                                     jaxb
                                            proxy.
                               

                                           
                                               