package com.remedy.arsys.border;

class GifEncoderHashitem
{
  public boolean isTransparent;
  public int count;
  public int index;
  public int rgb;

  public GifEncoderHashitem(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    this.rgb = paramInt1;
    this.count = paramInt2;
    this.index = paramInt3;
    this.isTransparent = paramBoolean;
  }
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.border.GifEncoderHashitem
 * JD-Core Version:    0.6.1
 */