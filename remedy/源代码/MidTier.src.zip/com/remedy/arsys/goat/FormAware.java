package com.remedy.arsys.goat;

public abstract interface FormAware
{
  public abstract void bindToForm(CachedFieldMap paramCachedFieldMap)
    throws GoatException;
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.FormAware
 * JD-Core Version:    0.6.1
 */