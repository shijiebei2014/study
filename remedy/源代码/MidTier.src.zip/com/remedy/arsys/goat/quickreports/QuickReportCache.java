package com.remedy.arsys.goat.quickreports;

public class QuickReportCache
{
  public boolean disabled;
  public String reportParam;

  public QuickReportCache(boolean paramBoolean, String paramString)
  {
    this.disabled = paramBoolean;
    this.reportParam = paramString;
  }
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.quickreports.QuickReportCache
 * JD-Core Version:    0.6.1
 */