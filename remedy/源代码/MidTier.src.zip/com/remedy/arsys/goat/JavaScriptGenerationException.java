package com.remedy.arsys.goat;

public class JavaScriptGenerationException extends GoatException
{
  public JavaScriptGenerationException(GoatException paramGoatException)
  {
    super(paramGoatException.getMessage(), paramGoatException);
  }
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.JavaScriptGenerationException
 * JD-Core Version:    0.6.1
 */