package com.remedy.arsys.goat.cache.sync;

public class SyncException extends Exception
{
  public SyncException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.cache.sync.SyncException
 * JD-Core Version:    0.6.1
 */