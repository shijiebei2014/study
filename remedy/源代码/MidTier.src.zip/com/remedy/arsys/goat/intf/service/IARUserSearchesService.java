package com.remedy.arsys.goat.intf.service;

import com.remedy.arsys.goat.savesearches.ARUserSearches;

public abstract interface IARUserSearchesService
{
  public abstract ARUserSearches getUserSearches(String paramString1, String paramString2, String paramString3, boolean paramBoolean);
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.intf.service.IARUserSearchesService
 * JD-Core Version:    0.6.1
 */