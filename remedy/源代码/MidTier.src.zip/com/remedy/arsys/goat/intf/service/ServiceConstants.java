package com.remedy.arsys.goat.intf.service;

public abstract interface ServiceConstants
{
  public static final String SERVICE_NAME_EMITTER_FACTORY = "emitterFactory";
  public static final String SERVICE_NAME_GOATFIELD_FACTORY = "goatfieldFactory";
  public static final String SERVICE_NAME_AR_USER_PREFERENCES_SERVICE = "arUserPreferencesService";
  public static final String SERVICE_NAME_AR_USER_SEARCHES_SERVICE = "arUserSearchesService";
  public static final String SERVICE_NAME_AR_SKIN_SERVICE = "skinService";
  public static final String SERVICE_NAME_AR_FORM_SERVICE = "formService";
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.intf.service.ServiceConstants
 * JD-Core Version:    0.6.1
 */