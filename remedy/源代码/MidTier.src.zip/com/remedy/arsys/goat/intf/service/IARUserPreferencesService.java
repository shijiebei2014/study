package com.remedy.arsys.goat.intf.service;

import com.remedy.arsys.goat.preferences.ARUserPreferences;

public abstract interface IARUserPreferencesService
{
  public abstract ARUserPreferences getUserPreferences();
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.intf.service.IARUserPreferencesService
 * JD-Core Version:    0.6.1
 */