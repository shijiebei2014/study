package com.remedy.arsys.goat;

class LCNumInfo
{
  public String dec;
  public String thsn;

  public LCNumInfo(String paramString1, String paramString2)
  {
    this.dec = paramString1;
    this.thsn = paramString2;
  }
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.LCNumInfo
 * JD-Core Version:    0.6.1
 */