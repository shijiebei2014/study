/*   */ package com.remedy.arsys.goat.service;
/*   */ 
/*   */ import org.aspectj.runtime.internal.AroundClosure;
/*   */ 
/*   */ public class ARUserPreferencesService$AjcClosure1 extends AroundClosure
/*   */ {
/*   */   public ARUserPreferencesService$AjcClosure1(Object[] paramArrayOfObject)
/*   */   {
/* 1 */     super(paramArrayOfObject); } 
/* 1 */   public Object run(Object[] paramArrayOfObject) { Object[] arrayOfObject = this.state; return ARUserPreferencesService.getUserPreferencesHelper_aroundBody0((ARUserPreferencesService)arrayOfObject[0], (ARUserPreferencesService)arrayOfObject[1]);
/*   */   }
/*   */ }

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.service.ARUserPreferencesService.AjcClosure1
 * JD-Core Version:    0.6.1
 */