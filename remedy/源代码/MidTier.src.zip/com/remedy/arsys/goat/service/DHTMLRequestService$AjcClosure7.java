/*   */ package com.remedy.arsys.goat.service;
/*   */ 
/*   */ import com.remedy.arsys.goat.Form.ViewInfo;
/*   */ import com.remedy.arsys.goat.intf.service.IFieldGraphService;
/*   */ import org.aspectj.runtime.internal.AroundClosure;
/*   */ 
/*   */ public class DHTMLRequestService$AjcClosure7 extends AroundClosure
/*   */ {
/*   */   public DHTMLRequestService$AjcClosure7(Object[] paramArrayOfObject)
/*   */   {
/* 1 */     super(paramArrayOfObject); } 
/* 1 */   public Object run(Object[] paramArrayOfObject) { Object[] arrayOfObject = this.state; return DHTMLRequestService.get_aroundBody6((DHTMLRequestService)arrayOfObject[0], (IFieldGraphService)arrayOfObject[1], (Form.ViewInfo)paramArrayOfObject[0]);
/*   */   }
/*   */ }

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.service.DHTMLRequestService.AjcClosure7
 * JD-Core Version:    0.6.1
 */