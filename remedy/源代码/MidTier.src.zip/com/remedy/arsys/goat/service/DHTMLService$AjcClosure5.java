/*   */ package com.remedy.arsys.goat.service;
/*   */ 
/*   */ import com.remedy.arsys.goat.ActiveLinkCollector;
/*   */ import com.remedy.arsys.goat.field.FieldGraph;
/*   */ import org.aspectj.runtime.internal.AroundClosure;
/*   */ 
/*   */ public class DHTMLService$AjcClosure5 extends AroundClosure
/*   */ {
/*   */   public DHTMLService$AjcClosure5(Object[] paramArrayOfObject)
/*   */   {
/* 1 */     super(paramArrayOfObject); } 
/* 1 */   public Object run(Object[] paramArrayOfObject) { Object[] arrayOfObject = this.state; return DHTMLService.getJSData_aroundBody4((DHTMLService)arrayOfObject[0], (DHTMLService)arrayOfObject[1], (FieldGraph)paramArrayOfObject[0], (ActiveLinkCollector)paramArrayOfObject[1]);
/*   */   }
/*   */ }

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.service.DHTMLService.AjcClosure5
 * JD-Core Version:    0.6.1
 */