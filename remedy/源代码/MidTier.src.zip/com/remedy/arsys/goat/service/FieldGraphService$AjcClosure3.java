/*   */ package com.remedy.arsys.goat.service;
/*   */ 
/*   */ import com.remedy.arsys.goat.Form.ViewInfo;
/*   */ import org.aspectj.runtime.internal.AroundClosure;
/*   */ 
/*   */ public class FieldGraphService$AjcClosure3 extends AroundClosure
/*   */ {
/*   */   public FieldGraphService$AjcClosure3(Object[] paramArrayOfObject)
/*   */   {
/* 1 */     super(paramArrayOfObject); } 
/* 1 */   public Object run(Object[] paramArrayOfObject) { Object[] arrayOfObject = this.state; return FieldGraphService.get_aroundBody2((FieldGraphService)arrayOfObject[0], (FieldGraphService)arrayOfObject[1], (Form.ViewInfo)paramArrayOfObject[0]);
/*   */   }
/*   */ }

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.goat.service.FieldGraphService.AjcClosure3
 * JD-Core Version:    0.6.1
 */