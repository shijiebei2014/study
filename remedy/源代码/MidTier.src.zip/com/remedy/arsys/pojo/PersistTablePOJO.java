package com.remedy.arsys.pojo;

public class PersistTablePOJO
{
  public int t;
  public String s;
  public String ts;
  public String vu;
  public String cs;
  public RowDataPOJO[] r;
}

/* Location:           D:\temp\原来桌面的\webapps\midtier_hpia32\WEB-INF\lib\MidTier.jar
 * Qualified Name:     com.remedy.arsys.pojo.PersistTablePOJO
 * JD-Core Version:    0.6.1
 */